--------------------
UrlShortener
--------------------
Version: 1.0.2
Author: Jan Peca <pecajan@gmail.com>
--------------------

UrlShortener for MODx Revolution. Now you can shorten URLs on your domain right in MODx.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/theboxer/UrlShortener/issues