<?php
/**
 * @package urlshortener
 */
class UrlShortenerItem extends xPDOSimpleObject {}
?>